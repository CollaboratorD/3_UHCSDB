#!/bin/bash
# use imagemagick commandline tools to generate thumbnails for uhcsdb web app
# usage: `bash setup/
SRC=uhcsdata/micrographs
DEST=uhcsdb/uhcsdb/static/thumbs

mkdir -p ${DEST}

for image in ${SRC}/*; do
    pngname=$(basename ${image%.*}.png)
    echo convert -resize 148x120 ${image} ${DEST}/${pngname}
    convert -resize 148x120 ${image} ${DEST}/${pngname}
done
