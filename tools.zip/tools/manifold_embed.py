#!/usr/bin/env python
import os
import h5py
import click
import numpy as np
import warnings
from sklearn.decomposition import PCA, KernelPCA
from sklearn.metrics.pairwise import chi2_kernel, additive_chi2_kernel
from sklearn.manifold import MDS, LocallyLinearEmbedding, SpectralEmbedding, Isomap

import ntsne

# make sure local python library under working dir is visible
import sys
sys.path.append(os.path.join(os.getcwd(), 'uhcsdata'))

import models
from models import Base, User, Collection, Sample, Micrograph
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

engine = create_engine('sqlite:///uhcsdata/microstructures.sqlite')
Base.metadata.bind = engine
DBSession = sessionmaker(bind=engine)
db = DBSession()

def load_representations(datafile):
    """ load image representations from HDF5 """
    keys, features = [], []

    with h5py.File(datafile, 'r') as f:
        for key in f:
            keys.append(key)
            features.append(f[key][...])

    return np.array(keys), np.array(features)

def store_params(group, model):
    """ Store model parameters as HDF5 attributes """
    if type(model) is dict:
        # model is a dict containing parameters for ntsne.best_tsne
        group.attrs['module'] = 'ntsne'
        group.attrs['class'] =  'best_tsne'
        for param, value in model.items():
            group.attrs[param] = value
    else:
        # model is a scikit-learn class
        group.attrs['module'] = model.__module__
        group.attrs['class'] = model.__class__.__name__
        group.attrs['repr'] = model.__repr__()
        for param, value in model.get_params().items():
            if value is None:
                value = 'None'
            group.attrs[param] = value
            
def save_embeddings(resultsfile, keys, embeddings, method, params):
    """ serialize reduced dimensionality representations to HDF5 """
    with h5py.File(resultsfile) as f:
        g = f.create_group(method)
        store_params(g, params)
        for idx, key in enumerate(keys):
            # add map point for each record
            g[key] = embeddings[idx]
        return


@click.command()
@click.argument('datafile', type=click.Path())
@click.option('--kernel', '-k', type=click.Choice(['linear', 'chi2']), default='linear')
@click.option('--method', '-m', type=click.Choice(['t-SNE', 'PCA', 'MDS', 'LLE', 'Isomap', 'SpectralEmbedding']), default='PCA')
@click.option('--n-repeats', '-r', type=int, default=1)
@click.option('--seed', '-s', type=int, default=None)
def manifold_embed(datafile, kernel, method, n_repeats, seed):
    """ manifold_embed
    python tools/manifold_embed.py uhcsdata/representations/vgg16_block5_conv3-vlad-32.h5
    """
    resultsfile = datafile.replace('representations', 'embed')
    
    keys, features = load_representations(datafile)
    labels = []    
    for key in keys:
        if '-' in key:
            # deal with cropped micrographs: key -> Micrograph.id-UL
            m_id, quadrant = key.split('-')
        else:
            m_id = key
        m = db.query(Micrograph).filter(Micrograph.micrograph_id == int(m_id)).one()
        labels.append(m.primary_microconstituent)
    labels = np.array(labels)

    if kernel == 'linear':
        x_pca = PCA(n_components=50).fit_transform(features)
    elif kernel == 'chi2':
        gamma = -1 / np.mean(additive_chi2_kernel(features))

        with warnings.catch_warnings():
            warnings.simplefilter("once", DeprecationWarning)
            x_pca = KernelPCA(n_components=50, kernel=chi2_kernel, gamma=gamma).fit_transform(features)
        
    r = {
        'PCA': PCA(n_components=2),
        'MDS': MDS(n_components=2),
        'LLE': LocallyLinearEmbedding(n_components=2, n_neighbors=10),
        'Isomap': Isomap(n_components=2),
        'SpectralEmbedding': SpectralEmbedding(n_components=2)
    }

    if method == 't-SNE':
        params = {'theta': 0.1, 'perplexity': 40, 'n_repeats': 10}
        x_embedding = ntsne.best_tsne(x_pca, perplexity=params['perplexity'],
                                      theta=params['theta'], n_repeats=params['n_repeats'])
        save_embeddings(resultsfile, keys, x_embedding, method, params)
    else:
        x_embedding = r[method].fit_transform(x_pca)
        save_embeddings(resultsfile, keys, x_embedding, method, r[method])
        
if __name__ == '__main__':
    manifold_embed()
