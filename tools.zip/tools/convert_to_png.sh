#!/bin/bash

# convert micrographs to png
# and move them to the static directory for uhcsdb app
DEST=uhcsdb/uhcsdb/static/micrographs

mkdir -p ${DEST}

for image in uhcsdata/micrographs/*; do
    pngname=$(basename ${image%.*}.png)
    echo convert -resize 50% ${image} ${DEST}/${pngname}
    convert -resize 50% ${image} ${DEST}/${pngname}
done
