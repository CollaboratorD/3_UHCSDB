UHCS dataset explorer
Built on Flask and Bokeh

Run flask app uhcsdb/uhcsdb.py in parallel with bokeh app uhcsdb/visualize.py

Store microstructure metadata in uhcsdb/microstructures.sqlite
Store image files under uhcsdb/static/micrographs.
Store image representations in HDF5 under uhcsdb/static/representations.
Store reduced-dimensionality representations in HDF5 under uhcsdb/static/embed.
